var class_sinric_pro_class =
[
    [ "ConnectedCallbackHandler", "class_sinric_pro_class.html#a4d7d8547a83d53c20cbd9aa7768e99f5", null ],
    [ "DisconnectedCallbackHandler", "class_sinric_pro_class.html#ad84930f3c26ac3692cc885be197d39c7", null ],
    [ "begin", "class_sinric_pro_class.html#ab19ffdad72d356ef0a32db068455a320", null ],
    [ "getTimestamp", "class_sinric_pro_class.html#afb2be26eef972203404140612fa31326", null ],
    [ "handle", "class_sinric_pro_class.html#a37c2d0658e498b1bf878f8a3d9a7c5b4", null ],
    [ "onConnected", "class_sinric_pro_class.html#ac33a355adfc413d4ff36974d735115bd", null ],
    [ "onDisconnected", "class_sinric_pro_class.html#a654bb017ca55b448d55bb36e0346f38a", null ],
    [ "operator[]", "class_sinric_pro_class.html#a9e5d96d0f1fb3409b3576e0107b97ce8", null ],
    [ "restoreDeviceStates", "class_sinric_pro_class.html#a27a9bb7f1e8bde0f39398649493b6f93", null ]
];