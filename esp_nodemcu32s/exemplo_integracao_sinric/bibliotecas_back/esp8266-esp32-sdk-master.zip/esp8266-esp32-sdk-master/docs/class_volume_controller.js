var class_volume_controller =
[
    [ "AdjustVolumeCallback", "class_volume_controller.html#ac6304129491317f85cee56ca5925dfab", null ],
    [ "SetVolumeCallback", "class_volume_controller.html#a5744ad6a31085c216c2193b0f2d86673", null ],
    [ "onAdjustVolume", "class_volume_controller.html#a2c868c87f96e3924c8b309e1bcfb507e", null ],
    [ "onSetVolume", "class_volume_controller.html#a5db8c85f222debbece54c794015f9402", null ],
    [ "sendVolumeEvent", "class_volume_controller.html#a0f301accc58742f867de88c66a5eb3c5", null ]
];