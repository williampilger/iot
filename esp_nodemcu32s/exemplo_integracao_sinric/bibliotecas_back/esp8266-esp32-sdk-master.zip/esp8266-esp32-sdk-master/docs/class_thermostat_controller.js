var class_thermostat_controller =
[
    [ "AdjustTargetTemperatureCallback", "class_thermostat_controller.html#a8d55dffbb520779ef95fc29e49032886", null ],
    [ "SetTargetTemperatureCallback", "class_thermostat_controller.html#a64ecf52eb927d219b3acabf01ad0d31f", null ],
    [ "ThermostatModeCallback", "class_thermostat_controller.html#a6cb473352a45a2ae76a46a4292c95a8c", null ],
    [ "onAdjustTargetTemperature", "class_thermostat_controller.html#ac51f6fecfdf4c7bc8e0712e2da47bbf4", null ],
    [ "onTargetTemperature", "class_thermostat_controller.html#a1c73725f1f3fbb1c5b72208aae5c2bf2", null ],
    [ "onThermostatMode", "class_thermostat_controller.html#a2ef31536973b20815dd6c80a28e19c9f", null ],
    [ "sendTargetTemperatureEvent", "class_thermostat_controller.html#a07632bca425003b4ad559cb46fabca8c", null ],
    [ "sendThermostatModeEvent", "class_thermostat_controller.html#acd81e847a7f1029163729574c3d3971d", null ]
];