var class_sinric_pro_camera =
[
    [ "PowerStateCallback", "class_sinric_pro_camera.html#aad370bc6b280bbdeac98181a31f22df4", null ],
    [ "onPowerState", "class_sinric_pro_camera.html#a32f3257da431a1035f23a265ff0cc4cf", null ],
    [ "sendPowerStateEvent", "class_sinric_pro_camera.html#a8006e256414deac0f9a4e28774b47773", null ]
];