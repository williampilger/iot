var class_percentage_controller =
[
    [ "AdjustPercentageCallback", "class_percentage_controller.html#a088a491b8656c376085bc31d558fd05d", null ],
    [ "SetPercentageCallback", "class_percentage_controller.html#a3ab0c4ff332f49884fe6a75cb2a293c2", null ],
    [ "onAdjustPercentage", "class_percentage_controller.html#a77ac70c4880e38dae4f640dceaeb2816", null ],
    [ "onSetPercentage", "class_percentage_controller.html#aeef432df118679c689ccd8a48d47dc3d", null ],
    [ "sendSetPercentageEvent", "class_percentage_controller.html#a940fd94e961b9b5fda5b836517f66767", null ]
];