var class_motion_controller =
[
    [ "sendMotionEvent", "class_motion_controller.html#ab28a28a17768a38eea033ba700095672", null ]
];