var class_toggle_controller =
[
    [ "GenericToggleStateCallback", "class_toggle_controller.html#a87371479ad42795e9dc9344bd02a6312", null ],
    [ "onToggleState", "class_toggle_controller.html#a7ccd28a4f20922847d0461649af5572d", null ],
    [ "sendToggleStateEvent", "class_toggle_controller.html#ab8156107c28c5fc2568be696b2c4d3e6", null ]
];