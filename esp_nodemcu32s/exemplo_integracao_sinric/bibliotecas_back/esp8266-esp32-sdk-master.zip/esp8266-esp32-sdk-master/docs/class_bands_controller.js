var class_bands_controller =
[
    [ "AdjustBandsCallback", "class_bands_controller.html#a28446c362f1f44e269b50619761c9e9b", null ],
    [ "ResetBandsCallback", "class_bands_controller.html#aa8c78de42c40ee03966f3c96cdc05bab", null ],
    [ "SetBandsCallback", "class_bands_controller.html#aaabec5dea3546d52e744a4b0b90c02f4", null ],
    [ "onAdjustBands", "class_bands_controller.html#a41a5c1506545c44c2408054a8675c7a8", null ],
    [ "onResetBands", "class_bands_controller.html#aa6c3aabc2b442d82ac5456ccaac3f60d", null ],
    [ "onSetBands", "class_bands_controller.html#a4aaa7a29394560be7537a86b0304d199", null ],
    [ "sendBandsEvent", "class_bands_controller.html#a4ad5674e36d96a73147388251b794c82", null ]
];