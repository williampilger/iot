var class_sinric_pro_temperaturesensor =
[
    [ "PowerStateCallback", "class_sinric_pro_temperaturesensor.html#aad370bc6b280bbdeac98181a31f22df4", null ],
    [ "onPowerState", "class_sinric_pro_temperaturesensor.html#a32f3257da431a1035f23a265ff0cc4cf", null ],
    [ "sendPowerStateEvent", "class_sinric_pro_temperaturesensor.html#a8006e256414deac0f9a4e28774b47773", null ],
    [ "sendTemperatureEvent", "class_sinric_pro_temperaturesensor.html#a9545808dacd9efc40a05f16e09d79b4e", null ]
];