var class_brightness_controller =
[
    [ "AdjustBrightnessCallback", "class_brightness_controller.html#a3ff8d93d9483f41bf8504fd3e9cc8f49", null ],
    [ "BrightnessCallback", "class_brightness_controller.html#aff9938ddc803e4339a3db9b31503e12d", null ],
    [ "onAdjustBrightness", "class_brightness_controller.html#a0633e5fa2981189f4a093bab00a8c7f1", null ],
    [ "onBrightness", "class_brightness_controller.html#abbaab3067b1fcdcc5928451b818a4420", null ],
    [ "sendBrightnessEvent", "class_brightness_controller.html#aa42df8ac91de826653626df67a8500b6", null ]
];