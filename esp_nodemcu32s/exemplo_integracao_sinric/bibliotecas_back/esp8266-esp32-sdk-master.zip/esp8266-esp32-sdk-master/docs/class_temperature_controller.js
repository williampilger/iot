var class_temperature_controller =
[
    [ "sendTemperatureEvent", "class_temperature_controller.html#a9545808dacd9efc40a05f16e09d79b4e", null ]
];