var searchData=
[
  ['changechannelcallback_362',['ChangeChannelCallback',['../class_channel_controller.html#a8bc108630d532266ae36cda5ec7b4857',1,'ChannelController']]],
  ['changechannelnumbercallback_363',['ChangeChannelNumberCallback',['../class_channel_controller.html#ab21b05b6f4a6be7e89a7173b7fafb552',1,'ChannelController']]],
  ['colorcallback_364',['ColorCallback',['../class_color_controller.html#ad8bcf09f6da3f41fffb001868cd3f84e',1,'ColorController']]],
  ['colortemperaturecallback_365',['ColorTemperatureCallback',['../class_color_temperature_controller.html#a9828094e72d45dc55a1023fd677f0cc5',1,'ColorTemperatureController']]],
  ['connectedcallbackhandler_366',['ConnectedCallbackHandler',['../class_sinric_pro_class.html#a4d7d8547a83d53c20cbd9aa7768e99f5',1,'SinricProClass']]]
];
