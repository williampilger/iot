var indexSectionsWithContent =
{
  0: "abcdeghiklmoprstv",
  1: "abcdeiklmprstv",
  2: "bghors",
  3: "abcdgiklmprst",
  4: "cds",
  5: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "typedefs",
  4: "groups",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Typedefs",
  4: "Modules",
  5: "Pages"
};

