var searchData=
[
  ['restoredevicestates_328',['restoreDeviceStates',['../class_sinric_pro_class.html#a27a9bb7f1e8bde0f39398649493b6f93',1,'SinricProClass']]]
];
