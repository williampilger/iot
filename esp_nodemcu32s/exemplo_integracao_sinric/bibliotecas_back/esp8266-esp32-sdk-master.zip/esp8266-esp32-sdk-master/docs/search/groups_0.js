var searchData=
[
  ['capabilities_391',['Capabilities',['../group___capabilities.html',1,'']]]
];
