var searchData=
[
  ['brightnesscallback_361',['BrightnessCallback',['../class_brightness_controller.html#aff9938ddc803e4339a3db9b31503e12d',1,'BrightnessController']]]
];
