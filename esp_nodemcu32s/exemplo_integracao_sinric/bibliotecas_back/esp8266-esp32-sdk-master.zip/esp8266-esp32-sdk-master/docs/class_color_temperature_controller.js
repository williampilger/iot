var class_color_temperature_controller =
[
    [ "ColorTemperatureCallback", "class_color_temperature_controller.html#a9828094e72d45dc55a1023fd677f0cc5", null ],
    [ "DecreaseColorTemperatureCallback", "class_color_temperature_controller.html#ae64ac4d2aa913eeb244091c7a13d2ecc", null ],
    [ "IncreaseColorTemperatureCallback", "class_color_temperature_controller.html#aed3d41935f8162074c2a2cc0168164dd", null ],
    [ "onColorTemperature", "class_color_temperature_controller.html#a8535c44fd2517ed09ebe6a203cc25b67", null ],
    [ "onDecreaseColorTemperature", "class_color_temperature_controller.html#a7468976e7fffeee14cc869b7236cbb50", null ],
    [ "onIncreaseColorTemperature", "class_color_temperature_controller.html#a7ea9fd9861a5668a41d06267bfbec82a", null ],
    [ "sendColorTemperatureEvent", "class_color_temperature_controller.html#a9065e6d08309d313b16adc774cc642ff", null ]
];